import java.util.Scanner;
public class StringCompare {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the first string: ");
        String str1 = input.nextLine();

        System.out.print("Enter the second string: ");
        String str2 = input.nextLine();

        System.out.println("\n--- Results ---");
        if (str1.equals(str2)) {
            System.out.println("The strings are EXACTLY the same.");
        } else {
            System.out.println("The strings are different.");
        }

        if (str1.equalsIgnoreCase(str2)) {
            System.out.println("The strings match if you ignore the case (capitalization).");
        } else {
            System.out.println("The strings are totally different, even ignoring case.");
        }
        
        input.close();
    }
}