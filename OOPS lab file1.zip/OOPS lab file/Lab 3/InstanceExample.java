class InstanceExample {
    int value = 200;
    public static void main(String[] args) {
        InstanceExample obj = new InstanceExample();

        System.out.println("Value without static: " + obj.value);
    }
}