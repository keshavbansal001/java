
class DataStore {
    String message;
    public DataStore(String input) {
        this.message = input;
        System.out.println("Constructor has been called!");
    }
    void display() {
        System.out.println("Message stored in object: " + message);
    }
    public static void main(String[] args) {
        DataStore myObj = new DataStore("Hello from Constructor");
        myObj.display();
    }
}