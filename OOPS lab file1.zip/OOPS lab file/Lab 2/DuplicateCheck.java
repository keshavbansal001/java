public class DuplicateCheck {
    boolean hasDuplicate = false;

    public static void main(String[] args) {
        DuplicateCheck obj = new DuplicateCheck();
        if (args.length == 0) {
            System.out.println("Enter array elements as arguments.");
            return;
        }
        for (int i = 0; i < args.length; i++) {
            for (int j = i + 1; j < args.length; j++) {
                if (args[i].equals(args[j])) {
                    obj.hasDuplicate = true;
                    break; 
                }
            }
            if (obj.hasDuplicate) break; 
        }
        if (obj.hasDuplicate) {
            System.out.println("The array contains duplicate elements.");
        } else {
            System.out.println("The array contains all unique elements.");
        }
    }
}