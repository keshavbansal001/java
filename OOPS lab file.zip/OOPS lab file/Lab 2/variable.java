public class variable {
    int totalSum = 0;
    public static void main(String[] args) {
        variable obj = new variable();

        if (args.length == 0) {
            System.out.println("Enter numbers as arguments.");
            return;
        }
        for (int i = 0; i < args.length; i++) {
            obj.totalSum += Integer.parseInt(args[i]);
        }

        System.out.println("Sum using object: " + obj.totalSum);
    }
}