public class SumArguments {
    int total = 0; 

    public static void main(String[] args) {
        SumArguments obj = new SumArguments();
        if (args.length == 0) {
            System.out.println("Enter numbers.");
            return;
        }
        for (int i = 0; i < args.length; i++) {
            obj.total += Integer.parseInt(args[i]); 
        }
        System.out.println("The sum is: " + obj.total);
    }
}