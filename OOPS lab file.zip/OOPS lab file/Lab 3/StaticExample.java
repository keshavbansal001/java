class StaticExample {
    static int value = 100;
    public static void main(String[] args) {
        System.out.println("Value using static: " + value);
        
    }
}