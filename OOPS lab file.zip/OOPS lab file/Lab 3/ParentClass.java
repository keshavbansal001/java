
class Parent {
    String value = "Parent Class Value";
}
class ChildClass extends Parent {
    String value = "Child Class Value";
    void display() {
        System.out.println("Using this: " + this.value);
        System.out.println("Using super: " + super.value);
    }
}
public class ParentClass {
    public static void main(String[] args) {
        ChildClass obj = new ChildClass();
        obj.display();
    }
}